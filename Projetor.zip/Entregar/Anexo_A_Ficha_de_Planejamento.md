# PROJETO FINAL — UC9: DESENVOLVER ALGORITMOS
## Anexo A — Ficha de Planejamento (Indicador 1)

**Curso Técnico em Informática — Senac RS · UC9 · Entrega individual**

```
NOME DO ALUNO: Rogério Augusto Simão Martins   TURMA: 6911   DATA: 16/10/2026
```

**Código-fonte:** `jogo.js` · **Execução:** `node jogo.js [Guerreiro | Mago | Arqueiro | Ladino] [Fogo | Água | Terra | Vento]` (monstro opcional; sem ele, é sorteado)

---

## 1. Nome do jogo

**Rogue, The New Era**

## 2. Regra de negócio em 1 frase

> "Herói e monstro duelam em turnos no terminal até que a vida de um deles chegue a zero, com habilidades que dependem de classe, mana e estância, e com parry e esquiva possíveis para ambos os lados."

## 3. Requisitos funcionais (o sistema FAZ — mínimo 6)

| # | Requisito funcional |
|---|---|
| **RF1** | **Criação dos personagens.** O sistema cria o herói (nome, classe, vida, mana, estância) e o monstro (nome, tipo, vida, ataque base, habilidade, fúria, estância) como **objetos**, por meio das funções de fábrica `criarHeroi(classe)` e `criarMonstro(tipo)`. O monstro vem do vetor `MONSTROS` (Sentinela de Brasa/Fogo, Golem de Maré/Água, Gárgula de Pedra/Terra, Espírito do Vendaval/Vento): é sorteado quando nenhum tipo é informado. |
| **RF2** | **Escolha da classe.** O sistema lê a classe digitada no terminal (`process.argv[2]`) e aceita `Guerreiro`, `Mago`, `Arqueiro` ou `Ladino` **sem diferenciar maiúsculas de minúsculas**, inclusive o início do nome (ex.: `l`, `lad`, `g`, `guer`). Se o valor for inválido (ex.: `gerreiro`) ou vazio, exibe um **aviso em português**, lista as opções válidas e assume a classe padrão **Mago**. Não há autocorreção de erros de digitação. O monstro (2º argumento, opcional) segue a mesma ideia: ignora acento e caixa (`agua`, `ÁGUA`), aceita a inicial e o nome; inválido avisa e sorteia. |
| **RF3** | **Batalha em turnos.** O sistema executa um laço `while` que conduz os turnos (herói → monstro) enquanto os dois estiverem vivos, e o encerra quando a vida de qualquer um chegar a 0 (com limite de 200 turnos como trava de segurança). A cada turno, herói e monstro sorteiam a estância: **Ataque** ou **Defesa**. |
| **RF4** | **Regras por classe e por tipo.** O sistema aplica condicionais para calcular dano e efeitos: Guerreiro (35 de dano em Ataque; +5 de vida em Defesa), Mago (ver RF5), Arqueiro (20 de dano; 35 contra monstro do tipo Fogo) e Ladino (ver RF6). Os bônus elementais ficam em `if / else if` que comparam `monstro.tipo` (ver RF10). O monstro causa o dano base do seu tipo (14, 12, 10 ou 16), o **dobro em Fúria**, e +5 de queimadura (tipo Fogo) contra herói em Ataque; quem está em **Defesa recebe metade do dano**. A Fúria é ativada quando a vida do monstro chega a 40% ou menos da **sua** vida máxima (60, 68, 76 ou 52). |
| **RF5** | **Gerenciamento de mana.** O Mago, com 15 ou mais de mana, usa **Bola de Fogo** (35 de dano, gasta 15 de mana); com menos mana usa **Ataque com Cajado** (10 de dano, recupera 10 de mana). Em Defesa, o Mago medita e recupera 5 de mana. |
| **RF6** | **Mecânica do Ladino (classe nova).** O Ladino ataca com **Ataque Furtivo** (28 de dano). A cada ataque, o sistema sorteia com `Math.random()` um **golpe crítico com 50% de chance**; no **Ataque Furtivo Crítico** o dano recebe **+50% de bônus** (28 + 14 = 42). |
| **RF7** | **Mecânica de Parry.** Se herói e monstro escolherem **Ataque no mesmo turno**, ocorre um choque de investidas: o dano é **zerado para ambos** e a mensagem de PARRY é exibida. |
| **RF8** | **Mecânica de Esquiva.** Quando um ataque vai atingir o alvo, o sistema sorteia, com `Math.random()`, se ele esquiva: **20% de chance para o herói** e **15% para o monstro**. Esquivando, o alvo **não sofre nenhum dano** naquele ataque. |
| **RF9** | **Histórico e relatório.** O sistema mostra no terminal o passo a passo de cada turno (estâncias, habilidade, dano causado ou evitado, status da rodada), registra cada ação em um **vetor de histórico** (`turno`, `agressor`, `habilidade`, `dano`, `alvo`, `vidaRestante`) e exibe o histórico completo ao final. |
| **RF10** | **Monstros elementais e fraquezas.** O sistema cria 4 monstros com vida, ataque e habilidade próprios e aplica vantagens por `if / else if`: **Água** (Golem de Maré, 170 HP, ataque 12) recebe a Bola de Fogo do Mago com +15 (35 → 50); **Fogo** (Sentinela de Brasa, 150 HP, ataque 14) recebe a Flecha Glacial do Arqueiro (20 + 15 = 35); **Terra** (Gárgula de Pedra, 190 HP, ataque 10) recebe o Golpe Esmagador do Guerreiro (25 + 10 + 10 = 45); **Vento** (Espírito do Vendaval, 130 HP, ataque 16) dá dano equilibrado a Mago, Guerreiro e Arqueiro e eleva o crítico do Ladino de 50% para 75%. Quando há vantagem, o console mostra `✨ Vantagem elemental`. |

## 4. Requisitos não funcionais (COMO o sistema deve ser — mínimo 3)

| # | Requisito não funcional |
|---|---|
| **RNF1** | O código deve rodar no ambiente **Node.js** (`node jogo.js`), sem bibliotecas externas, exibindo mensagens claras e estruturadas em português, sem `undefined` ou `NaN` no console. |
| **RNF2** | O sistema deve **validar limites**: nenhuma vida pode ficar abaixo de 0 (`Math.max(0, vida - dano)`), a cura do Guerreiro não pode passar da vida máxima (`Math.min`) e uma classe inválida não pode interromper o jogo. |
| **RNF3** | O código deve ser **organizado em funções reutilizáveis com nomes claros** (`criarHeroi`, `executarTurno`, `aplicarDano`, `resolverClasse`, `exibirHistorico` etc.), com as constantes de balanceamento no topo do arquivo. |
| **RNF4** | A batalha deve **sempre terminar**: o laço possui limite de 200 turnos, evitando repetição infinita. |

## 5. Personalização obrigatória — o que EU mudei (mínimo 3)

| | Personalização | Ponto do enunciado | Descrição |
|---|---|---|---|
| **a)** | **Tema, nomes e valores** | Ponto 1 | Universo "Rogue, The New Era": herói **Rogue** (120 de vida, 30 de mana) contra **quatro monstros elementais** (Sentinela de Brasa/Fogo, Golem de Maré/Água, Gárgula de Pedra/Terra, Espírito do Vendaval/Vento), cada um com vida, ataque e habilidade próprios (Investida Flamejante, Onda Esmagadora, Pancada de Rocha, Rajada Cortante), com fraquezas por classe e valores próprios de vida, dano, mana e chances. |
| **b)** | **Classe nova de herói: Ladino** | Ponto 2 | Quarta classe, com regra de ataque própria: **Ataque Furtivo** de 28 de dano e **50% de chance de crítico**, que soma +50% de bônus (42 de dano). Em Defesa, assume posição defensiva sem recuperação. |
| **c)** | **Regras de negócio novas: Parry e Esquiva** | Ponto 3 | **Parry:** se herói e monstro escolhem **Ataque** no mesmo turno, as investidas se chocam e o dano de **ambos é zerado**. **Esquiva:** herói (20%) e monstro (15%) podem esquivar de um ataque, sorteado com `Math.random()`; esquivando, o dano recebido é **zero**. |

## 6. Estruturas de dados (indicador 5)

| Estrutura | Tipo (objeto/vetor/matriz) | Para que serve |
|-----------|---------------------------|----------------|
| `heroi` | **Objeto** | Armazena os atributos do jogador: `nome` ("Rogue"), `classe`, `vida`, `vidaMax`, `mana` e `estance` ("Ataque" ou "Defesa"). Criado por `criarHeroi(classe)`. |
| `monstro` | **Objeto** | Armazena os atributos do inimigo: `nome`, `tipo` ("Fogo", "Água", "Terra" ou "Vento"), `vida`, `vidaMax`, `ataqueBase`, `habilidade`, `emFuria` (booleano) e `estance`. Criado por `criarMonstro(tipo)`. |
| `MONSTROS` | **Vetor (array) de objetos** | Catálogo com os 4 modelos de monstro (`nome`, `tipo`, `vida`, `ataqueBase`, `habilidade`). `criarMonstro` usa `find` para achar o tipo pedido ou sorteia um índice com `Math.random()`. |
| `historico` | **Vetor (array) de objetos** | Armazena o registro de cada ação da batalha, na ordem em que ocorrem. Cada elemento é `{turno, agressor, habilidade, dano, alvo, vidaRestante}`. Alimentado por `registrarHistorico()` e percorrido por `exibirHistorico()` com `for...of`. |
| `CLASSES_VALIDAS` | **Vetor (array) de strings** | Lista `["Guerreiro", "Mago", "Arqueiro", "Ladino"]`, usada para validar a classe digitada no terminal e para listar as opções no aviso de erro. |

## 7. Esqueleto do fluxo (pseudocódigo do turno)

```
INÍCIO DO PROGRAMA
  classe ← resolverClasse(argumento do terminal)   // sem diferenciar maiúsculas; aceita início do nome;
                                                   // inválida ou vazia → aviso em português + "Mago"
  heroi ← criarHeroi(classe)                       // Rogue: 120 HP, 30 mana
  monstro ← criarMonstro(tipo do 2º argumento)     // Fogo, Água, Terra ou Vento; sem tipo: sorteia
  historico ← []
  turno ← 1

  ENQUANTO (batalha não terminou E heroi.vida > 0 E monstro.vida > 0 E turno ≤ 200):

    1. SORTEAR ESTÂNCIAS
         heroi.estance   ← "Ataque" (65%) ou "Defesa" (35%)
         monstro.estance ← "Ataque" (60%) ou "Defesa" (40%)

    2. HERÓI AGE
         SE heroi.estance = "Ataque":
              SE classe = Mago:       SE mana ≥ 15 → Bola de Fogo (35 de dano, mana −15; +15 se monstro.tipo = "Água")
                                      SENÃO       → Ataque com Cajado (10 de dano, mana +10)
              SE classe = Guerreiro:  SE monstro.tipo = "Terra" → Golpe Esmagador (45 de dano)
                                      SENÃO                   → Golpe Ofensivo (35 de dano)
              SE classe = Arqueiro:   SE monstro.tipo = "Fogo" → Flecha Glacial (35 de dano)
                                      SENÃO                    → Tiro de Arco (20 de dano)
              SE classe = Ladino:     SORTEAR crítico (50%; 75% se monstro.tipo = "Vento")
                                      SE crítico → Ataque Furtivo Crítico (28 + 50% = 42 de dano)
                                      SENÃO      → Ataque Furtivo (28 de dano)
         SENÃO (Defesa):
              Guerreiro → vida +5 (até vidaMax) · Mago → mana +5 · Arqueiro e Ladino → nada
              registrar no histórico

    3. VERIFICAR PARRY
         SE heroi.estance = "Ataque" E monstro.estance = "Ataque":
              PARRY → dano = 0 para ambos; registrar 2 linhas no histórico; ir para o passo 6

    4. ATAQUE DO HERÓI (se atacou)
         SE sorteio de esquiva do monstro (15%) → dano = 0 ("ESQUIVOU")
         SENÃO: SE monstro.estance = "Defesa" → dano ← dano ÷ 2
                monstro.vida ← Math.max(0, monstro.vida − dano)
         registrar no histórico
         SE monstro.vida = 0 → exibir VITÓRIA e ENCERRAR a batalha
         SE monstro.vida ≤ 40% de vidaMax E ainda não está em fúria → emFuria ← verdadeiro

    5. ATAQUE DO MONSTRO
         SE monstro.estance = "Ataque":
              SE sorteio de esquiva do herói (20%) → dano = 0 ("ESQUIVOU")
              SENÃO: dano ← ataqueBase
                     SE emFuria → dano ← dano × 2
                     SE tipo = "Fogo" E heroi.estance = "Ataque" → dano ← dano + 5   (queimadura)
                     SE heroi.estance = "Defesa" → dano ← dano ÷ 2
                     heroi.vida ← Math.max(0, heroi.vida − dano)
              registrar no histórico
              SE heroi.vida = 0 → exibir DERROTA e ENCERRAR a batalha
         SENÃO: monstro em postura defensiva, não ataca (registrar no histórico)

    6. EXIBIR STATUS DA RODADA (vida do herói, mana, vida do monstro)
       turno ← turno + 1

  FIM-ENQUANTO
  SE saiu por limite de turnos → exibir "empate"
  EXIBIR HISTÓRICO COMPLETO (percorrer o vetor com for...of)
FIM
```
