// ====================================================================
//  ROGUE, THE NEW ERA — Batalha de RPG em turnos (Node.js)
//  Projeto Final UC9 — Desenvolver Algoritmos (Senac RS)
//  Aluno: Rogério Augusto Simão Martins · Turma 6911
//  Uso: node jogo.js [Guerreiro | Mago | Arqueiro | Ladino] [Fogo | Água | Terra | Vento]
//       (o monstro é opcional; sem ele, é sorteado)
// ====================================================================

const readline = require("readline");

// ---------- Configurações ----------
const CHANCE_ESQUIVA_HEROI = 0.2;
const CHANCE_ESQUIVA_MONSTRO = 0.15;
const CHANCE_HEROI_ATACAR = 0.65;
const CHANCE_MONSTRO_ATACAR = 0.6;
const CHANCE_CRITICO_LADINO = 0.5;
const BONUS_CRITICO_LADINO = 0.5;
const LIMITE_FURIA = 0.4;
const LIMITE_TURNOS = 200;
const CLASSES_VALIDAS = ["Guerreiro", "Mago", "Arqueiro", "Ladino"];
const CLASSE_PADRAO = "Mago";

// Vantagens elementais (bônus de dano bruto ou de chance de crítico)
const BONUS_BOLA_DE_FOGO_VS_AGUA = 15; // Mago x Golem de Maré
const BONUS_FLECHA_GLACIAL_VS_FOGO = 15; // Arqueiro x Sentinela de Brasa
const BONUS_GUERREIRO_VS_TERRA = 10; // Guerreiro x Gárgula de Pedra
const CHANCE_CRITICO_LADINO_VS_VENTO = 0.75; // Ladino x Espírito do Vendaval

// Catálogo de monstros elementais (vida, ataque e habilidade próprios)
const MONSTROS = [
  {
    nome: "Sentinela de Brasa",
    tipo: "Fogo",
    vida: 150,
    ataqueBase: 14,
    habilidade: "Investida Flamejante",
  },
  {
    nome: "Golem de Maré",
    tipo: "Água",
    vida: 170,
    ataqueBase: 12,
    habilidade: "Onda Esmagadora",
  },
  {
    nome: "Gárgula de Pedra",
    tipo: "Terra",
    vida: 190,
    ataqueBase: 10,
    habilidade: "Pancada de Rocha",
  },
  {
    nome: "Espírito do Vendaval",
    tipo: "Vento",
    vida: 130,
    ataqueBase: 16,
    habilidade: "Rajada Cortante",
  },
];

// ---------- R1: personagens (funções de fábrica) ----------
function criarHeroi(classe) {
  return {
    nome: "Rogue",
    classe: classe,
    vida: 120,
    vidaMax: 120,
    mana: 30,
    estance: "Ataque",
  };
}

// Sem argumento sorteia o monstro; com um tipo ("Fogo", "Água", "Terra",
// "Vento") cria exatamente aquele.
function criarMonstro(tipo) {
  let modelo = MONSTROS.find((m) => m.tipo === tipo);
  if (modelo === undefined) {
    modelo = MONSTROS[Math.floor(Math.random() * MONSTROS.length)];
  }

  return {
    nome: modelo.nome,
    tipo: modelo.tipo,
    vida: modelo.vida,
    vidaMax: modelo.vida,
    ataqueBase: modelo.ataqueBase,
    habilidade: modelo.habilidade,
    emFuria: false,
    estance: "Ataque",
  };
}

// ---------- Funções auxiliares ----------
function sortear(chance) {
  return Math.random() < chance;
}

function aplicarDano(personagem, dano) {
  personagem.vida = Math.max(0, personagem.vida - dano);
}

function registrarHistorico(
  historico,
  turno,
  agressor,
  habilidade,
  dano,
  alvo,
  vidaRestante,
) {
  historico.push({ turno, agressor, habilidade, dano, alvo, vidaRestante });
}

function escolherEstance(personagem, chanceAtacar) {
  personagem.estance = sortear(chanceAtacar) ? "Ataque" : "Defesa";
}

function verificarFuria(monstro) {
  if (!monstro.emFuria && monstro.vida <= monstro.vidaMax * LIMITE_FURIA) {
    monstro.emFuria = true;
    console.log(
      `  🔥 ${monstro.nome} entrou em FÚRIA! O dano dele agora dobra!`,
    );
  }
}

// Valida a classe digitada: sem diferenciar maiúsculas, aceita o início do
// nome (ex.: "lad") e, se for inválida, avisa e assume a classe padrão.
function resolverClasse(entrada) {
  if (entrada === undefined || entrada.trim() === "") {
    return {
      classe: CLASSE_PADRAO,
      aviso: `Nenhuma classe informada. Usando "${CLASSE_PADRAO}" (padrão). Opções: ${CLASSES_VALIDAS.join(", ")}.`,
    };
  }

  const texto = entrada.trim().toLowerCase();

  const exata = CLASSES_VALIDAS.find((nome) => nome.toLowerCase() === texto);
  if (exata !== undefined) {
    return { classe: exata, aviso: "" };
  }

  const porPrefixo = CLASSES_VALIDAS.filter((nome) =>
    nome.toLowerCase().startsWith(texto),
  );
  if (porPrefixo.length === 1) {
    return {
      classe: porPrefixo[0],
      aviso: `"${entrada}" interpretado como "${porPrefixo[0]}".`,
    };
  }

  return {
    classe: CLASSE_PADRAO,
    aviso:
      `⚠️  Classe "${entrada}" digitada incorretamente. ` +
      `Opções válidas: ${CLASSES_VALIDAS.join(", ")}. ` +
      `Usando "${CLASSE_PADRAO}" (padrão).`,
  };
}

// Sem diferenciar maiúsculas nem acentos: "Água" e "agua" ficam iguais.
function semAcento(texto) {
  return texto
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

// Valida o monstro digitado (opcional): aceita o tipo ("agua", "ÁGUA"), a
// inicial ("a", "f", "t", "v") ou o nome completo. Vazio => sorteio.
function resolverMonstro(entrada) {
  if (entrada === undefined || entrada.trim() === "") {
    return { tipo: undefined, aviso: "" };
  }

  const texto = semAcento(entrada);

  const exato = MONSTROS.find(
    (m) => semAcento(m.tipo) === texto || semAcento(m.nome) === texto,
  );
  if (exato !== undefined) {
    return { tipo: exato.tipo, aviso: "" };
  }

  const porPrefixo = MONSTROS.filter((m) =>
    semAcento(m.tipo).startsWith(texto),
  );
  if (porPrefixo.length === 1) {
    return {
      tipo: porPrefixo[0].tipo,
      aviso: `"${entrada}" interpretado como "${porPrefixo[0].tipo}".`,
    };
  }

  return {
    tipo: undefined,
    aviso:
      `⚠️  Monstro "${entrada}" digitado incorretamente. ` +
      `Opções válidas: ${MONSTROS.map((m) => m.tipo).join(", ")}. ` +
      `Sorteando um monstro.`,
  };
}

// ---------- Regras de combate ----------
// Devolve o dano BRUTO (antes de esquiva, parry e defesa) e se houve
// vantagem elemental contra o tipo do monstro.
function calcularAtaqueHeroi(heroi, monstro) {
  let habilidade = "";
  let dano = 0;
  let vantagem = false;

  if (heroi.classe === "Mago") {
    if (heroi.mana >= 15) {
      habilidade = "Bola de Fogo";
      dano = 35;
      heroi.mana -= 15;
      if (monstro.tipo === "Água") {
        dano += BONUS_BOLA_DE_FOGO_VS_AGUA;
        vantagem = true;
      }
    } else {
      habilidade = "Ataque com Cajado";
      dano = 10;
      heroi.mana += 10;
    }
  } else if (heroi.classe === "Guerreiro") {
    if (monstro.tipo === "Terra") {
      habilidade = "Golpe Esmagador";
      dano = 25 + 10 + BONUS_GUERREIRO_VS_TERRA;
      vantagem = true;
    } else {
      habilidade = "Golpe Ofensivo";
      dano = 25 + 10;
    }
  } else if (heroi.classe === "Arqueiro") {
    if (monstro.tipo === "Fogo") {
      habilidade = "Flecha Glacial";
      dano = 20 + BONUS_FLECHA_GLACIAL_VS_FOGO;
      vantagem = true;
    } else {
      habilidade = "Tiro de Arco";
      dano = 20;
    }
  } else if (heroi.classe === "Ladino") {
    let chanceCritico = CHANCE_CRITICO_LADINO;
    if (monstro.tipo === "Vento") {
      chanceCritico = CHANCE_CRITICO_LADINO_VS_VENTO;
      vantagem = true;
    }

    if (sortear(chanceCritico)) {
      habilidade = "Ataque Furtivo Crítico";
      dano = 28 + Math.floor(28 * BONUS_CRITICO_LADINO);
    } else {
      habilidade = "Ataque Furtivo";
      dano = 28;
    }
  }

  return { habilidade, dano, vantagem };
}

function executarDefesaHeroi(heroi) {
  if (heroi.classe === "Guerreiro") {
    const vidaAntes = heroi.vida;
    heroi.vida = Math.min(heroi.vidaMax, heroi.vida + 5);
    return {
      habilidade: "Postura de Escudo",
      efeito: `+${heroi.vida - vidaAntes} de vida`,
    };
  }
  if (heroi.classe === "Mago") {
    heroi.mana += 5;
    return { habilidade: "Meditação", efeito: "+5 de mana" };
  }
  return { habilidade: "Posição Defensiva", efeito: "sem recuperação" };
}

function calcularDanoMonstro(monstro, heroi) {
  let dano = monstro.ataqueBase;

  if (monstro.emFuria) {
    dano *= 2;
  }
  if (monstro.tipo === "Fogo" && heroi.estance === "Ataque") {
    dano += 5;
  }
  return dano;
}

// ---------- R2 / R3: turno e relatório ----------
// Executa um turno; devolve true se a batalha terminou.
function executarTurno(turno, heroi, monstro, historico) {
  console.log(`\n=== TURNO ${turno} ===`);

  escolherEstance(heroi, CHANCE_HEROI_ATACAR);
  escolherEstance(monstro, CHANCE_MONSTRO_ATACAR);
  console.log(
    `  ${heroi.nome} escolheu ${heroi.estance} | ${monstro.nome} escolheu ${monstro.estance}`,
  );

  let ataqueHeroi = null;
  if (heroi.estance === "Ataque") {
    ataqueHeroi = calcularAtaqueHeroi(heroi, monstro);
    if (ataqueHeroi.vantagem) {
      console.log(
        `  ✨ Vantagem elemental contra ${monstro.tipo}! (${ataqueHeroi.habilidade})`,
      );
    }
  } else {
    const defesa = executarDefesaHeroi(heroi);
    console.log(
      `  🛡️  ${heroi.nome} usou ${defesa.habilidade} (${defesa.efeito}).`,
    );
    registrarHistorico(
      historico,
      turno,
      heroi.nome,
      defesa.habilidade,
      0,
      heroi.nome,
      heroi.vida,
    );
  }

  // Parry: os dois atacam => ninguém toma dano
  const ocorreuParry =
    heroi.estance === "Ataque" && monstro.estance === "Ataque";

  if (ocorreuParry) {
    console.log(
      `  ⚔️  PARRY! ${heroi.nome} (${ataqueHeroi.habilidade}) e ${monstro.nome} se chocaram. Dano zerado para ambos!`,
    );
    registrarHistorico(
      historico,
      turno,
      heroi.nome,
      `${ataqueHeroi.habilidade} (Parry)`,
      0,
      monstro.nome,
      monstro.vida,
    );
    registrarHistorico(
      historico,
      turno,
      monstro.nome,
      `${monstro.habilidade} (Parry)`,
      0,
      heroi.nome,
      heroi.vida,
    );
  } else {
    // Ataque do herói (com esquiva do monstro)
    if (ataqueHeroi !== null) {
      if (sortear(CHANCE_ESQUIVA_MONSTRO)) {
        console.log(
          `  💨 ${monstro.nome} ESQUIVOU de ${ataqueHeroi.habilidade}! Nenhum dano.`,
        );
        registrarHistorico(
          historico,
          turno,
          heroi.nome,
          `${ataqueHeroi.habilidade} (Esquivado)`,
          0,
          monstro.nome,
          monstro.vida,
        );
      } else {
        let dano = ataqueHeroi.dano;

        if (monstro.estance === "Defesa") {
          dano = Math.floor(dano / 2);
          console.log(
            `  🛡️  ${monstro.nome} se defendeu e reduziu o dano pela metade.`,
          );
        }

        aplicarDano(monstro, dano);
        console.log(
          `  ⚔️  ${heroi.nome} usou ${ataqueHeroi.habilidade} e causou ${dano} de dano!`,
        );
        registrarHistorico(
          historico,
          turno,
          heroi.nome,
          ataqueHeroi.habilidade,
          dano,
          monstro.nome,
          monstro.vida,
        );
      }

      if (monstro.vida === 0) {
        console.log(
          `\n🏆 ${monstro.nome} foi derrotado! Vitória de ${heroi.nome}!`,
        );
        return true;
      }

      verificarFuria(monstro);
    }

    // Ataque do monstro (com esquiva do herói)
    if (monstro.estance === "Ataque") {
      if (sortear(CHANCE_ESQUIVA_HEROI)) {
        console.log(
          `  💨 ${heroi.nome} ESQUIVOU do ataque de ${monstro.nome}! Nenhum dano.`,
        );
        registrarHistorico(
          historico,
          turno,
          monstro.nome,
          `${monstro.habilidade} (Esquivado)`,
          0,
          heroi.nome,
          heroi.vida,
        );
      } else {
        let dano = calcularDanoMonstro(monstro, heroi);

        if (heroi.estance === "Defesa") {
          dano = Math.floor(dano / 2);
          console.log(
            `  🛡️  ${heroi.nome} se defendeu e reduziu o dano pela metade.`,
          );
        }

        aplicarDano(heroi, dano);
        console.log(
          `  💥 ${monstro.nome} usou ${monstro.habilidade} e causou ${dano} de dano!`,
        );
        registrarHistorico(
          historico,
          turno,
          monstro.nome,
          monstro.habilidade,
          dano,
          heroi.nome,
          heroi.vida,
        );
      }

      if (heroi.vida === 0) {
        console.log(`\n💀 ${heroi.nome} foi derrotado em combate!`);
        return true;
      }
    } else {
      console.log(
        `  🛡️  ${monstro.nome} ficou em postura defensiva e não atacou.`,
      );
      registrarHistorico(
        historico,
        turno,
        monstro.nome,
        "Postura Defensiva",
        0,
        heroi.nome,
        heroi.vida,
      );
    }
  }

  console.log(
    `  📊 Status -> ${heroi.nome}: ${heroi.vida} HP | ${heroi.mana} Mana --- ` +
      `${monstro.nome}: ${monstro.vida} HP${monstro.emFuria ? " (FÚRIA)" : ""}`,
  );

  return false;
}

function exibirHistorico(historico) {
  console.log("\n===== HISTÓRICO DA BATALHA =====");

  for (const registro of historico) {
    console.log(
      `Turno ${registro.turno} | ${registro.agressor} -> ${registro.alvo} | ` +
        `${registro.habilidade} | dano: ${registro.dano} | vida do alvo: ${registro.vidaRestante}`,
    );
  }
}

// ---------- Programa principal ----------
function iniciarJogo() {
  const { classe, aviso } = resolverClasse(process.argv[2]);

  if (aviso !== "") {
    console.log(aviso);
  }

  const escolhaMonstro = resolverMonstro(process.argv[3]);

  if (escolhaMonstro.aviso !== "") {
    console.log(escolhaMonstro.aviso);
  }

  const heroi = criarHeroi(classe);
  const monstro = criarMonstro(escolhaMonstro.tipo);
  const historico = [];

  console.log("==========================================");
  console.log("          ROGUE, THE NEW ERA");
  console.log("==========================================");
  console.log(
    `${heroi.nome} (${heroi.classe}) — ${heroi.vida} HP, ${heroi.mana} Mana`,
  );
  console.log("                 VS");
  console.log(
    `${monstro.nome} (${monstro.tipo}) — ${monstro.vida} HP, ataque ${monstro.ataqueBase}`,
  );

  // R2: laço de turnos
  let turno = 1;
  let terminou = false;

  while (
    !terminou &&
    heroi.vida > 0 &&
    monstro.vida > 0 &&
    turno <= LIMITE_TURNOS
  ) {
    terminou = executarTurno(turno, heroi, monstro, historico);
    turno++;
  }

  if (!terminou) {
    console.log("\n⏳ Limite de turnos atingido. A batalha terminou empatada.");
  }

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  rl.question("Mostrar histórico da batalha? (y/n) ", (resposta) => {
    rl.close();
    const r = resposta.trim().toLowerCase();
    if (r === "y" || r === "s" || r === "yes" || r === "sim" || r === "") {
      exibirHistorico(historico);
    } else {
      console.log("Histórico omitido.");
    }
  });
}

iniciarJogo();
