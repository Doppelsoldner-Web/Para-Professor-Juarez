# PROJETO FINAL — UC9: DESENVOLVER ALGORITMOS
## Anexo B — Tabela de Testes e Teste de Mesa (Indicadores 4 e 5)

**Aluno:** Rogério Augusto Simão Martins · **Turma:** 6911 · **Data:** 16/10/2026
**Jogo:** Rogue, The New Era · **Código-fonte:** `jogo.js` (`node jogo.js [classe] [monstro]`)

---

**Como os testes foram executados.** Os testes foram rodados de verdade contra o arquivo `jogo.js`, por meio do script `testes.js`, que carrega o código real. Nos casos T1 a T16 e T22 a T31, o `Math.random()` é substituído por valores fixos para **forçar cada situação** (estância, esquiva, crítico) e tornar o resultado reproduzível. T15, T17, T23 e T28 usam sorteios reais em grande quantidade. T18 a T21 e T32 executam o programa no terminal. **Os 32 testes foram aprovados** (`TOTAL: 32/32 aprovados`). Os testes T1 a T16 usam o monstro de Fogo (Sentinela de Brasa).

**Monstros elementais e vantagens (referência dos testes T22 a T32):**

| Monstro | Tipo | Vida | Ataque base | Habilidade | Fraqueza |
|---------|------|------|-------------|------------|----------|
| Sentinela de Brasa | Fogo | 150 | 14 | Investida Flamejante | Arqueiro (Flecha Glacial 20 + 15 = 35) |
| Golem de Maré | Água | 170 | 12 | Onda Esmagadora | Mago (Bola de Fogo 35 + 15 = 50) |
| Gárgula de Pedra | Terra | 190 | 10 | Pancada de Rocha | Guerreiro (Golpe Esmagador 25 + 10 + 10 = 45) |
| Espírito do Vendaval | Vento | 130 | 16 | Rajada Cortante | Ladino (crítico sobe de 50% para 75%); as outras classes sem bônus |

## Tabela de Testes

| ID | O que testa | Entrada / cenário | Resultado esperado | Resultado obtido | OK? |
|----|-------------|-------------------|--------------------|------------------|-----|
| T1 | Ataque normal (Guerreiro) | Guerreiro em Ataque contra a Sentinela de Brasa | Golpe Ofensivo com 35 de dano bruto (25 + 10) | Golpe Ofensivo, dano bruto 35 | ✅ |
| T2 | Habilidade por mana (Mago) — **caso-limite** (14 < 15) | Mago com 14 de mana ataca | Ataque com Cajado com 10 de dano; mana sobe para 24 | Ataque com Cajado, dano 10, mana 24 | ✅ |
| T3 | Fúria dobra o dano | Monstro em fúria com `ataqueBase` 15 contra herói em Defesa (dano bruto) | Dano bruto de 30 (15 × 2) | Dano bruto 30 | ✅ |
| T4 | Redução de dano por Defesa | Guerreiro em Defesa (vida 120) recebe ataque de `ataqueBase` 20, sem esquiva | Dano 20 reduzido a 10; vida 120 → 110 | Vida 110 (perdeu 10) | ✅ |
| T5 | Vida mínima do herói — **caso-limite** | Arqueiro com 5 de vida em Defesa recebe ataque de 14 (14 ÷ 2 = 7) | Vida final **0** (não -2), turno termina com derrota | Vida 0, turno terminou, derrota exibida | ✅ |
| T6 | Fim de batalha e vida mínima do monstro — **caso-limite** | Monstro com 10 de vida em Defesa recebe golpe de 35 (35 ÷ 2 = 17) | Vida final **0** (não -7), vitória | Vida 0, turno terminou, vitória exibida | ✅ |
| T7 | **Parry** | Herói e monstro escolhem Ataque no mesmo turno | PARRY, vidas intactas, 2 registros com dano 0 | Herói 120 HP, monstro 150 HP, PARRY exibido, danos `[0,0]` | ✅ |
| T8 | **Esquiva do monstro** | Herói ataca, monstro em Defesa, esquiva do monstro sorteada | Monstro sem dano; histórico com dano 0 | Monstro 150 HP, ESQUIVOU exibido, dano 0 | ✅ |
| T9 | **Esquiva do herói** | Monstro ataca, esquiva do herói sorteada | Herói sem dano; histórico com dano 0 | Herói 120 HP, ESQUIVOU exibido, dano 0 | ✅ |
| T10 | Ativação da Fúria | Monstro com 70 de vida recebe 35 ÷ 2 = 17: 70 → 53, abaixo de 60 (40% de 150) | Vida 53, `emFuria = true` e mensagem | Vida 53, `emFuria=true`, mensagem exibida | ✅ |
| T11 | Mana gasta pela Bola de Fogo (Mago) | Mago com 30 de mana ataca a Sentinela (Fogo, sem bônus) | Bola de Fogo com 35 de dano; mana 15 | Bola de Fogo, dano 35, mana 15 | ✅ |
| T12 | Bônus de tipo (Arqueiro x Fogo) | Arqueiro ataca a Sentinela de Brasa | Flecha Glacial com 35 de dano (20 + 15) | Flecha Glacial, dano bruto 35 | ✅ |
| T13 | **Ladino** — Ataque Furtivo sem crítico | Sorteio do crítico falha | Ataque Furtivo com 28 | Ataque Furtivo, dano bruto 28 | ✅ |
| T14 | **Ladino** — Ataque Furtivo Crítico | Sorteio do crítico acerta | Ataque Furtivo Crítico com 42 (28 + 50%) | Ataque Furtivo Crítico, dano bruto 42 | ✅ |
| T15 | **Ladino** — frequência do crítico (vs Fogo) | 10 000 ataques com `Math.random()` real | Só 28 ou 42; críticos próximos de 50% | 4957 críticos (49,6%); nenhum valor diferente de 28 ou 42 | ✅ |
| T16 | **Ladino** em Defesa | Ladino escolhe Defesa | Posição Defensiva, sem recuperação | Posição Defensiva; vida 120, mana 30 | ✅ |
| T17 | Estresse: vida nunca negativa e batalha sempre termina | 1000 batalhas por classe (250 contra cada um dos 4 monstros), `Math.random()` real | Nenhuma vida abaixo de 0 e nenhum estouro do limite de turnos | Menor vida 0 nas 4 classes; 0 estouros; máx. de turnos: Guerreiro 96, Mago 133, Arqueiro 124, Ladino 108; vitórias do herói: 1000, 773, 719 e 928 de 1000 | ✅ |
| T18 | Classe sem diferenciar maiúsculas | `node jogo.js` com `ladino`, `LADINO`, `Ladino`, `lAdInO`, `ArQuEiRo`, `"  mago  "` | Classe reconhecida, sem aviso | `Rogue (Ladino)` ×4, `Rogue (Arqueiro)`, `Rogue (Mago)`; nenhum aviso | ✅ |
| T19 | Classe abreviada | `l`, `lad`, `g`, `guer`, `m`, `mag`, `a`, `arq` | Ladino, Ladino, Guerreiro, Guerreiro, Mago, Mago, Arqueiro, Arqueiro | Exatamente o esperado | ✅ |
| T20 | Classe inválida — aviso e padrão (sem autocorreção) | `gerreiro`, `magu`, `bardo`, `ladinoo` | Aviso de digitação incorreta, opções e Mago | `⚠️ Classe "gerreiro" digitada incorretamente. Opções válidas: Guerreiro, Mago, Arqueiro, Ladino. Usando "Mago" (padrão).` e `Rogue (Mago)`; o mesmo para os outros três | ✅ |
| T21 | Classe ausente — **caso-limite** | `node jogo.js` sem argumento e com `""` | Aviso de classe ausente e Mago | `Nenhuma classe informada. Usando "Mago" (padrão). Opções: ...` e `Rogue (Mago)` | ✅ |
| T22 | **Monstros elementais** — propriedades | `criarMonstro("Fogo")`, `("Água")`, `("Terra")`, `("Vento")` | Nome, tipo, vida, vidaMax e ataque base de cada um; sem fúria | Sentinela de Brasa 150/14; Golem de Maré 170/12; Gárgula de Pedra 190/10; Espírito do Vendaval 130/16 | ✅ |
| T23 | **Sorteio** do monstro | `criarMonstro()` sem argumento, 8000 vezes | Os 4 tipos aparecem, cada um perto de 25% | Fogo 25,6%, Água 25,6%, Terra 24,5%, Vento 24,3% | ✅ |
| T24 | **Vantagem Mago x Água** | Mago (30 de mana) usa Bola de Fogo contra cada tipo | Água: 50 de dano (35 + 15), mana 15; demais: 35 | Água 50 (vantagem=true, mana 15); Fogo, Terra e Vento 35 | ✅ |
| T25 | **Vantagem Arqueiro x Fogo** | Arqueiro ataca cada tipo | Fogo: Flecha Glacial 35; demais: Tiro de Arco 20 | Fogo 35 (Flecha Glacial); Água, Terra, Vento 20 (Tiro de Arco) | ✅ |
| T26 | **Vantagem Guerreiro x Terra** | Guerreiro ataca cada tipo | Terra: Golpe Esmagador 45 (25 + 10 + 10); demais: Golpe Ofensivo 35 | Terra 45 (Golpe Esmagador); Fogo, Água, Vento 35 | ✅ |
| T27 | **Vento equilibrado** para Mago, Guerreiro e Arqueiro | Cada classe ataca o Espírito do Vendaval | Sem bônus: Mago 35, Guerreiro 35, Arqueiro 20 | Mago 35, Guerreiro 35, Arqueiro 20; nenhuma vantagem | ✅ |
| T28 | **Ladino x Vento** — crítico de 75% | 10 000 ataques do Ladino contra Vento e contra Fogo | Vento perto de 75%; Fogo perto de 50% | Vento 75,4%; Fogo 49,9%; só valores 28 e 42 | ✅ |
| T29 | Vantagem dentro do turno completo | Herói em Ataque, monstro em Defesa, sem esquiva | Mensagem de vantagem e dano pela metade: Mago x Golem 25 (170 → 145); Guerreiro x Gárgula 22 (190 → 168); Arqueiro x Sentinela 17 (150 → 133); Arqueiro x Vendaval sem mensagem, 10 (130 → 120) | Todos conforme o esperado | ✅ |
| T30 | Habilidade própria de cada monstro | Monstro ataca herói em Defesa; e Parry | Dano base ÷ 2 e nome da habilidade no histórico, também com `(Parry)` | Fogo: Investida Flamejante 7; Água: Onda Esmagadora 6; Terra: Pancada de Rocha 5; Vento: Rajada Cortante 8; Parry com o nome certo | ✅ |
| T31 | Fúria proporcional à vida máxima — **caso-limite** | Gárgula (190 HP, fúria com vida ≤ 76) leva 45 ÷ 2 = 22 | 100 → 78: sem fúria; 80 → 58: fúria | 100 → 78, `emFuria=false`; 80 → 58, `emFuria=true` | ✅ |
| T32 | Escolha do monstro no terminal | `node jogo.js lad <monstro>` com `agua`, `ÁGUA`, `Fogo`, `f`, `t`, `v`, `golem de mare`; inválidos `lava`, `xyz`; sem argumento | Monstro certo sem diferenciar acento ou caixa; inválido: aviso + sorteio; vazio: sorteio sem aviso | Golem, Golem, Sentinela, Sentinela, Gárgula, Vendaval, Golem; aviso `Monstro "lava" digitado incorretamente...` com sorteio; sem argumento sorteia sem aviso | ✅ |

## Teste de Mesa (5 turnos)

**Cenário:** classe **Ladino**, herói com 120 de vida e 30 de mana, contra a **Sentinela de Brasa (Fogo)** já ferida, com 80 de vida (sem fúria), para a fúria aparecer dentro dos 5 turnos. Os sorteios foram forçados para exercitar caminhos diferentes do código: crítico, defesa do monstro, fúria, Parry e Esquiva dos dois lados. Os valores vêm da execução do código real. O Ladino não usa mana, por isso a coluna **Mana** permanece em 30. Contra o Fogo o Ladino não tem vantagem elemental (crítico de 50%).

| Turno | Condição testada | Caminho executado | Vida herói | Vida monstro | Mana | Histórico (última linha) |
|-------|------------------|-------------------|-----------|--------------|------|--------------------------|
| 1 | Herói em **Ataque** × monstro em **Defesa**; **crítico do Ladino**; **ativação da Fúria** | Ladino sorteia crítico e usa Ataque Furtivo Crítico (28 + 14 = 42). Sem esquiva do monstro; como ele está em Defesa, o dano cai pela metade: 42 ÷ 2 = 21 (80 → 59). Com 59 ≤ 60 (40% de 150), o monstro entra em **fúria**. Monstro em Defesa não contra-ataca | 120 | 59 | 30 | `{turno:1, agressor:"Sentinela de Brasa", habilidade:"Postura Defensiva", dano:0, alvo:"Rogue", vidaRestante:120}` |
| 2 | **Parry** (ambos em Ataque) | O crítico é sorteado e falha (Ataque Furtivo, 28), mas os golpes se chocam e o dano é zerado para os dois; o turno termina sem ataques | 120 | 59 | 30 | `{turno:2, agressor:"Sentinela de Brasa", habilidade:"Investida Flamejante (Parry)", dano:0, alvo:"Rogue", vidaRestante:120}` |
| 3 | Herói em **Defesa** × monstro em **Ataque** (sem esquiva), com **monstro em fúria** | Ladino assume Posição Defensiva (sem recuperação). Dano do monstro: 14 × 2 (fúria) = 28; sem queimadura, pois o herói não está em Ataque; Defesa reduz pela metade: 28 ÷ 2 = 14 | 106 | 59 | 30 | `{turno:3, agressor:"Sentinela de Brasa", habilidade:"Investida Flamejante", dano:14, alvo:"Rogue", vidaRestante:106}` |
| 4 | **Esquiva do herói** | Herói em Defesa; o monstro ataca, mas o sorteio de esquiva do herói acerta e o dano é anulado | 106 | 59 | 30 | `{turno:4, agressor:"Sentinela de Brasa", habilidade:"Investida Flamejante (Esquivado)", dano:0, alvo:"Rogue", vidaRestante:106}` |
| 5 | **Esquiva do monstro** (sem crítico) | Ladino ataca sem crítico (Ataque Furtivo, 28), mas o monstro esquiva e o dano é anulado. Monstro em Defesa não ataca (o registro `Ataque Furtivo (Esquivado)` vem logo antes da postura defensiva) | 106 | 59 | 30 | `{turno:5, agressor:"Sentinela de Brasa", habilidade:"Postura Defensiva", dano:0, alvo:"Rogue", vidaRestante:106}` |

**Observação sobre o crítico:** no Turno 2 o crítico do Ladino é sorteado mesmo havendo Parry, porque o golpe é preparado antes de o choque ser resolvido.

## Teste de mesa complementar — vantagem elemental (Mago × Golem de Maré)

Mago com 30 de mana, herói em Ataque, **Golem de Maré (Água, 170 HP)** em Defesa, sem esquiva (cenário do teste T29):

| Passo | Cálculo | Resultado |
|-------|---------|-----------|
| 1. Habilidade | Mana 30 ≥ 15, então Bola de Fogo; mana 30 − 15 | mana 15 |
| 2. Dano bruto | 35 + 15 (bônus contra Água) | 50, com a mensagem `✨ Vantagem elemental contra Água!` |
| 3. Golem em Defesa | 50 ÷ 2, arredondado para baixo | 25 |
| 4. Aplicar dano | `Math.max(0, 170 − 25)` | vida do Golem 145 |

**Observação:** como o Parry anula o turno quando os dois atacam, o golpe só atinge o monstro quando ele está em Defesa. Por isso o dano que chega ao alvo é sempre metade do dano bruto (50 vira 25); a vantagem elemental continua valendo, pois o dano bruto sobe de 35 para 50.
